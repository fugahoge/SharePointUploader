---
marp: true
theme: default
_class: lead
paginate: true
backgroundColor: #ffffff
backgroundImage: url('https://fugahoge.github.io/background2.png')
footer: 'Copyright 2025'
style: |
  footer {
    color: #ffffff;
    z-index: 1;
    bottom: 5px;
    font-size: 12pt;
    letter-spacing: 1px;
  }
  section::after {
    color: #ffffff;
    left: 50%;
    bottom: 5px;
    font-size: 12pt;
    letter-spacing: 1px;
  }
  h1 {
    color: #000000;
    position: absolute;
    border-left: 10px solid #000000;
    padding: 3px 0 3px 18px;
    top: 10px;
    left: 34px;
    font-size: 28pt;
    letter-spacing: 1px;
  }
  section.title {
      justify-content: center;
      text-align: center;
  }
  section {
    justify-content: start;
  }
  table {
    position: center;
    table-layout: auto;
    width: 100%;
    display:table;
  }
  th {
    color: #ffffff;
    background-color: #b2b2b2;
  }
  td {
    background-color: #ffffff
  }
---
<!-- _class: title -->
## Blazor Server と Docker
### 2025/xx/xx

---
# アジェンダ

1. 概要
1. Blazorの概要
1. 他技術との比較  
1. Dockerの概要
1. 実際の利用イメージ
1. まとめ

---
# 概要

### ■ 背景
ソフト開発を効率化する技術やツールを利用したり再利用性を高めることは、成果物の品質の向上やチームの生産性アップにつながります。
チームでのソフト開発効率の向上が期待できる技術について調査を行いました。

### ■ 目的
- 近年注目されているデスクトップアプリの技術を用いたWebの開発手法の一つであるMicrosoft Blazor（Server）の技術調査
- 環境構築に仮想化技術を適用することで、チーム内の開発環境の統一および、
デプロイの効率化を期待できるDockerの開発作業への適用検証

<br>
<center>
Blazor Server、Dockerの概要と、それぞれを組み合わせた際の利点を紹介します。
</center>

---
# Blazorの概要

## Blazorとは
Microsoftが開発した ASP.NET Core に含まれる Web フレームワークで、バックエンドだけでなくフロントエンドの UI ロジックも C# で開発することができます。

<div style="display: flex;">

<div style="flex: 1;">

## Blazorの特徴
- Microsoftが開発したフレームワーク
- C#とRazor構文でWebアプリを開発可
- UI部品の再利用が容易な設計
- **2種類のホスティングモデル**がある

→将来的に「Blazor United」に統合予定

</div>
<div style="flex: 1;">

### Blazorのホスティングモデル
<div style="font-size: 0.7em;">

| 観点 | Blazor Server | Blazor WASM |
|------|--------------|-------------|
| UIのレンダリング | サーバーサイド | Webブラウザ |
| イベント通信方式 | SignalR | HTTP |
| 初期ロード時間 | 短い | 遅い |
| オフライン対応 | 不可 | 可能 |
| スケーラビリティ | サーバー依存 | クライアント依存 |

</div>
</div>

</div>

---
# Blazorの概要

<div style="display: flex;">
<div style="flex: 2;">

## Blazor Serverとは

ブラウザで動作するBlazor WASMと異なり、Blazor Server では UI のイベント処理は**サーバー側で実行**されます。
従来のASPから乗り換えて使用することが想定されており、ASPとの親和性を意識した仕様になっています。

## Blazor Serverの特徴
- イベント処理はサーバーサイドで実行
- UIやデータの状態もサーバー側で一元管理
- 従来のASPと親和性の高い設計

</div>
<div style="flex: 1;">

<div style="display: flex; justify-content: center; align-items: center; height: 100%;">
<img src="blazor_docker_img_1.drawio.svg" style="transform: scale(1.5);" />
</div>

</div>
</div>

---
# Blazorの概要

## Blazor のメリット

| 特徴 | 説明 |
|------|------|
| 開発言語 | C# のみでフロント・バックエンド両方の開発が可能 |
| コンポーネント志向 | UI を部品化でき、再利用や分担が容易 |
| クロスプラットフォーム | Windows以外のLinuxやmacOSでもホスティング可能 |

## まとめ

- C# だけでモダンなWebアプリの開発が可能で学習コストを抑えられる
- コンポーネントベースの開発が可能で再利用性の高いコーディングが可能
- Windows以外でもホスティング可能で実行環境の仮想化に対するハードルが低い

---
# 既存技術との比較

## 一般的なJSフレームワークとの違い
| 観点 | Blazor Server | JSフレームワーク (React等) |
|------|----------------|-----------------------------|
| 言語 | C# のみ| JS/TS(サーバサイドは別言語) |
| UIレンダリング | サーバーサイド | クライアントサイド |
| スケーラビリティ | サーバーリソースが必要 | クライアント分散型 |
| 初期ロード時間 | 比較的重い | 軽量で高速 |

<br>

- JSフレームワークは豊富なライブラリと実績があるが、異なる言語の習得が必要
- Blazorは既存のC#/.NET資産やスキルを活用できる
- パフォーマンスを重視する場合はJSフレームワークの方が優位



---
# Dockerの概要

<div style="display: flex;">
<div style="flex: 2;">

## Dockerとは
Docker は、アプリケーションとその実行環境をまとめてパッケージングする仮想化技術です。

## Dockerの特徴
- アプリと依存するコンポーネントをパッケージングすることで実行環境の配布が容易
- 従来の仮想化技術と比較して仮想イメージのリソース効率が優れていて動作が軽量・高速
- 仮想化によってOSやライブラリの違いを吸収することができるので、環境起因のトラブルを回避できる

</div>
<div style="flex: 1;">

<div style="display: flex; justify-content: center; align-items: center; height: 100%;">
<img src="blazor_docker_img_2.drawio.svg" style="transform: scale(1.5);" />
</div>

</div>
</div>

---
# Dockerの概要
## Dockerのメリット

| 特徴 | 説明 |
|------|------|
| パッケージング | アプリケーションと実行環境を一体化して配布可能 |
| リソース効率 | 従来の仮想化技術と比べて軽量で高速に動作 |
| 環境の一貫性 | 開発からデプロイまで同一環境での実行が可能 |

## まとめ
- 実行環境が統一できるので環境差異に起因するトラブルを回避できる
- 開発環境の構築やデプロイ作業を自動化・効率化できる
- Linuxの仕様に依存しているので仮想化できるのはLinuxの環境のみ

---
# 実際の利用イメージ
## Blazor × Docker の組み合わせによるメリット

Blazor Server で開発したアプリを Docker と組み合わせることで下記の特徴がある
- BlazorはマルチOS対応なのでLinuxを前提とするDockerのメリットを生かせる
- APサーバだけでなく、DBも含めたサーバ構成全体を丸ごと配布可能

### 改善が期待できる課題
| 課題 | 対処法（技術観点） |
|----------|----------------|
| 実行環境の差異に起因するトラブル | 実行環境の統一（Docker） |
| フロントとバックエンドの分離が面倒 | C#での一貫した開発（Blazor） |
| 開発環境構築・デプロイの手間 | 実行環境の仮想化（Docker） |


---
# まとめ

- **Blazor Server**：使い慣れたC#でWeb開発を可能にするフレームワーク
- **Docker**：開発・検証本番を問わず、アプリの実行環境を統一できる仮想化技術
➡ 組み合わせて利用することで開発効率の向上・生産性の向上を期待できる

## 現状課題
- 登場から間もない発展途上の技術なので書籍やBlog等の公式以外の情報が少ない
- 後方互換性のない変更が何度も行われていて、Web上の情報の新旧判別が難しい
➡ 現状、メジャーな技術と比べて**トラブルが発生した際の調査対応コストが高い**

## 参考資料
- [Blazor 公式ドキュメント](https://docs.microsoft.com/aspnet/core/blazor/)
- [Docker 公式ドキュメント](https://docs.docker.com/)



---
# fin
